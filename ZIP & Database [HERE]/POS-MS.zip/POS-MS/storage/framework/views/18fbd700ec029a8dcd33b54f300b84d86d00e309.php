

<?php $__env->startSection('location'); ?>
    TRANSACTIONS : 
    <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($sale->SalesID); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container" style="margin-top: 10px">
        <div class="row">
            <div class="col-6">
                <a href="<?php echo e(route('admin.transactions')); ?>" class="btn btn-yellow ">Back</a>
                <!-- <button class="btn btn-yellow" type="button">Back</button> -->
            </div>
        </div>

        <div class="row">
            <div class="container">
                <table class="table table-hover">
                    <thead>
                    <tr style="text-align: center">
                        <th scope="col">SalesID</th>
                        <th scope="col">ProductID</th>
                        <th scope="col">Product Name</th>
                        <th scope="col">Quantity</th>
                        <!-- <th scope="col">Load Amount</th> -->
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr style="align-content: center; text-align: center;">
                            <th scope="row"><?php echo e($detail->SalesID); ?></th>
                            <td><?php echo e($detail->ProductID); ?></td>
                            <td><?php echo e($detail->ProductName); ?></td>
                            <td><?php echo e($detail->Quantity); ?></td>
                            <!-- <td><?php echo e($detail->LoadAmount); ?></td> -->
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    </tbody>
                </table>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('masterlayout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\POS-MS\resources\views/admin/transactionDetails.blade.php ENDPATH**/ ?>