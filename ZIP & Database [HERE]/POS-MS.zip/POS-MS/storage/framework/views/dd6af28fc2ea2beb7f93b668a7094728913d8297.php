

<?php $__env->startSection('location'); ?>
    DASHBOARD
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="container" style="margin-top: 10px; max-width: 50rem;">
        <div class="row row-cols-2">

        <div class="col">
            <div class="card text-white mb-3 blue-bg" style="max-width: 20rem;">
                
                <div class="card-body" style="text-align: center">
                    <i class="fas fa-shopping-cart fa-5x"></i>
                </div>

                <div class="card-footer" style="text-align: center">
                    <button class="btn btn-yellow" type="button"><b>View Products</b></button>
                </div>
                
            </div>
        </div>

        <div class="col">
            <div class="card text-white mb-3 blue-bg" style="max-width: 20rem;">
                
                <div class="card-body" style="text-align: center">
                    <i class="far fa-credit-card fa-5x"></i>
                </div>

                <div class="card-footer" style="text-align: center">
                    <button class="btn btn-yellow" type="button"><b>Add Transaction</b></button>
                </div>
                
            </div>
        </div>

        <div class="col">
            <div class="card text-white mb-3 blue-bg" style="max-width: 20rem;">
                
                <div class="card-body" style="text-align: center">
                    <i class="fas fa-users fa-5x"></i>
                </div>

                <div class="card-footer" style="text-align: center">
                    <button class="btn btn-yellow" type="button"><b>User Management</b></button>
                </div>
                
            </div>
        </div>

        <div class="col">
            <div class="card text-white mb-3 blue-bg" style="max-width: 20rem;">
                
                <div class="card-body" style="text-align: center">
                    <i class="fas fa-file-alt fa-5x"></i>
                </div>

                <div class="card-footer" style="text-align: center">
                    <button class="btn btn-yellow" type="button">Reports</button>
                </div>
                
            </div>
        </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterlayout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\POS-MS\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>