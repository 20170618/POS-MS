<!DOCTYPE html>
<html lang="en">
    <head></head>
    <body>
        <h1>Migui's Store Report</h1>
        <h5>taena mu symfony</h5>
        <p><?php echo date("Y/m/d"); ?></p>
    </body>
</html><?php /**PATH C:\xampp\htdocs\POS-MS\resources\views/test.blade.php ENDPATH**/ ?>