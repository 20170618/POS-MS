
<!DOCTYPE html>
<html lang="en"></html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"> 

        <title>Point of Sale Migui's Store</title>
     
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
        <link href="../../../css/bootstrap.css" rel="stylesheet">
        <link href="../../../css/sidebar.css" rel="stylesheet">
        <link rel="stylesheet" href="//cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">

        <script src="https://kit.fontawesome.com/ad9a071612.js" crossorigin="anonymous"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/5.5.2/bootbox.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"
            integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous">
        </script>

        <script src="../../../js/sidebar.js"></script>
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    </head>

    <body>
        <div class="container-fluid">
            <div class="container-fluid">
                
            
                <div class="row">
        
                    <h2 style="margin-top: 5px">
                        REPORT PREVIEW
                        <button class="btn btn-yellow" id="GenerateButton" type="submit" style="float: right">Export To PDF</button>
                    </h2>

                    <hr>

                    <div class="row">
                        <h4 style="text-align: center">Migui's Store Report</h4>
                        <h5 style="text-align: center">Date Created: <?php echo e($now); ?></h5>
                        <h5 style="text-align: center">Start Date: <?php echo e($startDate); ?> End Date: <?php echo e($endDate); ?></h3>
                    </div>
                        <div class="row">
                            <div class="col">
                                <h5>Number of Sales: <?php echo e($sales); ?></h5>
                            </div>
                            <div class="col">
                                <h5>Number of Debts: <?php echo e($debts); ?></h5>
                            </div>
                        </div>
                        
                        
                            
                            <h5 style="text-align: center">Sales Breakdown</h5>

                            <?php if(in_array('Consumable', $categories) || in_array('allCheck', $categories)): ?>
                                <div>
                            <?php else: ?>
                                <div hidden>
                            <?php endif; ?>
                            
                                <h5>Consumable</h5>
                                <table class="table table-light">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>Product Name</th>
                                            <th># Sold</th>
                                            <th>Sale Per Product</th>
                                        </tr>
                                        
                                    </thead>
                                    <tbody>
                                        <?php if($consumableSales == '[]'): ?>
                                            <tr>
                                                <td colspan="3" style="text-align: center">No Products</td>
                                            </tr> 
                                        <?php else: ?>
                                            <?php
                                            $totalCon = 0    
                                            ?>
                                            <?php $__currentLoopData = $consumableSales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consumableSale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($consumableSale->ProductName); ?></td>
                                                <td><?php echo e($consumableSale->sold); ?></td>
                                                <td><?php echo e($consumableSale->cost); ?></td>
                                            </tr>
                                            <?php
                                            $totalCon += $consumableSale->cost    
                                            ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td colspan="2" style="text-align: right">Total:</td>
                                                <td><b><?php echo e($totalCon); ?></b></td>
                                            </tr>

                                                

                                        <?php endif; ?>                                  
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                            <?php if(in_array('Non-Consumable', $categories) || in_array('allCheck', $categories)): ?>
                                <div>
                            <?php else: ?>
                                <div hidden>
                            <?php endif; ?>
                            
                                <h5>Non-Consumable</h5>
                                <table class="table table-light">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>Product Name</th>
                                            <th># Sold</th>
                                            <th>Sale Per Product</th>
                                        </tr>
                                        
                                    </thead>
                                    <tbody>
                                        <?php if($nonConsumableSales == '[]'): ?>
                                            <tr>
                                                <td colspan="3" style="text-align: center">No Products</td>
                                            </tr> 
                                        <?php else: ?>
                                            <?php
                                            $totalNCon = 0    
                                            ?>
                                            <?php $__currentLoopData = $nonConsumableSales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nonConsumableSale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($nonConsumableSale->ProductName); ?></td>
                                                <td><?php echo e($nonConsumableSale->sold); ?></td>
                                                <td><?php echo e($nonConsumableSale->cost); ?></td>
                                            </tr>
                                            <?php
                                            $totalNCon += $nonConsumableSale->cost
                                            ?>
                                            
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td colspan="2" style="text-align: right">Total:</td>
                                                <td><b><?php echo e($totalNCon); ?></b></td>
                                            </tr>
                                        <?php endif; ?>                                  
                                        
                                    </tbody>
                                </table>
                            </div>

                            <?php if(in_array('E-Load', $categories) || in_array('allCheck', $categories)): ?>
                                <div>
                            <?php else: ?>
                                <div hidden>
                            <?php endif; ?>
                            
                                <h5>E-Load</h5>
                                <table class="table table-light">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>Product Name</th>
                                            <th>Sale Per Product</th>
                                        </tr>
                                        
                                    </thead>
                                    <tbody>
                                        <?php if($eLoadSales == '[]'): ?>
                                            <tr>
                                                <td colspan="3" style="text-align: center">No Products</td>
                                            </tr> 
                                        <?php else: ?>
                                            <?php
                                            $totalELoad = 0    
                                            ?>
                                            <?php $__currentLoopData = $eLoadSales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eLoadSale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($eLoadSale->ProductName); ?></td>
                                                <td><?php echo e($eLoadSale->sold); ?></td>
                                            </tr>
                                            <?php
                                            $totalELoad += $eLoadSale->sold
                                            ?>
                                            
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td colspan="1" style="text-align: right">Total:</td>
                                                <td><b><?php echo e($totalELoad); ?></b></td>
                                            </tr>
                                        <?php endif; ?>                                  
                                        
                                    </tbody>
                                </table>
                            </div>

                            <h5 style="text-align: center">Products Out of Stock</h5>
                            <table class="table table-light">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Product Name</th>
                                        <th>Category</th>
                                        <th>Stock</th>
                                    </tr>
                                     
                                </thead>
                                <tbody>
                                    <?php if($outOfStocks == '[]'): ?>
                                        <tr>
                                            <td colspan="3" style="text-align: center">No Products</td>
                                        </tr> 
                                    <?php else: ?>
                                        <?php $__currentLoopData = $outOfStocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outOfStock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($outOfStock->ProductName); ?></td>
                                            <td><?php echo e($outOfStock->Category); ?></td>
                                            <td><?php echo e($outOfStock->Stock); ?></td>
                                        </tr> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>                                  
                                     
                                </tbody>
                            </table>
    
    
                </div>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\POS-MS\resources\views/reportPreview.blade.php ENDPATH**/ ?>