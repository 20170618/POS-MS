hello
this is a test
<?php /**PATH C:\xampp\htdocs\POS-MS\resources\views/auth/firstSetup.blade.php ENDPATH**/ ?>