

<?php $__env->startSection('location'); ?>
    HOME
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

                        <?php if(Session::has('error')): ?>
                            <div class="alert alert-danger alert-dismissible fade show">
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                <strong>Error!</strong> <?php echo session('error'); ?>

                            </div>
                        <?php endif; ?>

    <div class="container" style="margin-top: 10px; max-width: 50rem;">
        <div class="row row-cols-2">

        <div class="col">
            <div class="card text-white mb-3 blue-bg" style="max-width: 20rem;">

                <div class="card-body" style="text-align: center">
                    <i class="fas fa-shopping-cart fa-5x"></i>
                </div>

                <div class="card-footer" style="text-align: center">
                    <a class="btn btn-yellow" href="../admin/products"><b>View Products</b></a>
                </div>

            </div>
        </div>

        <div class="col">
            <div class="card text-white mb-3 blue-bg" style="max-width: 20rem;">

                <div class="card-body" style="text-align: center">
                    <i class="far fa-credit-card fa-5x"></i>
                </div>

                <div class="card-footer" style="text-align: center">
                    <a class="btn btn-yellow" href="../admin/transactions"><b>Add Transaction</b></a>
                </div>

            </div>
        </div>

        <div class="col">
            <div class="card text-white mb-3 blue-bg" style="max-width: 20rem;">

                <div class="card-body" style="text-align: center">
                    <i class="fas fa-users fa-5x"></i>
                </div>

                <div class="card-footer" style="text-align: center">
                    <a class="btn btn-yellow" href="../admin/userManagement"><b>User Management</b></a>
                </div>

            </div>
        </div>

        <div class="col">
            <div class="card text-white mb-3 blue-bg" style="max-width: 20rem;">

                <div class="card-body" style="text-align: center">
                    <i class="fas fa-file-alt fa-5x"></i>
                </div>

                <div class="card-footer" style="text-align: center">
                    <a class="btn btn-yellow" href="../admin/reports"><b>Reports</b></a>
                </div>

            </div>
        </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('masterlayout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\POS-MS\resources\views/admin/home.blade.php ENDPATH**/ ?>