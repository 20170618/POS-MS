<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"> 

        <title>

        <?php echo $__env->yieldContent('title',"POS-MS"); ?>

        </title>
        
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
        <link href="../../css/bootstrap.css" rel="stylesheet">
        
        <script src="https://kit.fontawesome.com/ad9a071612.js" crossorigin="anonymous"></script>    
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/5.5.2/bootbox.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
        
    </head>

    <body>     
        <div class="container" style="margin: 10rem">
            <div class="row">

                <div class="col-6" style="text-align: center; margin-top: 10rem;">
                    <!--
                    <img class="img-fluid" src="../../images/migui store.png" alt="migui store">
                    -->
                    <h1>MIGUI'S STORE</h1>
                    <small class="text-muted">POINT-OF-SALE-SYSTEM</small>
                </div>

                <div class="col-6" style="align-content: center">
                    <div class="card text-white bg-primary mb-3" style="width: 30rem">
                        <div class="card-body">
                        <h4 class="card-title">Login</h4>

                        <form>
                            <fieldset>
                            <div class="form-group">
                                <label for="exampleInputEmail1" class="form-label mt-4">Username or Email</label>
                                <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Username or Email">

                            </div>

                            <div class="form-group">
                                <label for="exampleInputPassword1" class="form-label mt-4">Password</label>
                                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                                <small>Forgot your Password? Recover your account here.</small>
                            </div>

                            &nbsp;

                            <div class="row">
                                <div class="col-8">
                                    <small>Don't have an account? Sign up here</small>
                                </div>

                                <div class="col-4">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-warning">Log in</button>
                                    </div>
                                </div>
                            </div>
                            </fieldset>
                        </form>

                        </div>
                    </div>
                </div>

            </div>
        </div>

    </body>
</html><?php /**PATH C:\xampp\htdocs\POS-MS\resources\views/main.blade.php ENDPATH**/ ?>