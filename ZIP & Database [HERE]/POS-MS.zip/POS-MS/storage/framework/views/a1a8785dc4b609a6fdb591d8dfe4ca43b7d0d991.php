

<?php $__env->startSection('location'); ?>
    USER MANAGEMENT
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="container" style="margin-top: 10px;width: 90rem">
        <div class="row">

            <div class="col-7">
                <div class="card text-white mb-3 blue-bg">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-7">
                                <h4 class="yellow">Active Users</h4>
                            </div>

                        </div>

                        &nbsp;

                        <div class="row">
                            <div class="container">
                                <table class="table table-hover">
                                    <thead>
                                    <tr class="table-yellow">
                                        <th scope="col">Name</th>
                                        <th scope="col">Type</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php $__currentLoopData = $actives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $active): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="table-light">
                                            <th scope="row"><?php echo e($active->FirstName); ?> <?php echo e($active->LastName); ?></th>
                                            <td><?php echo e($active->UserType); ?></td>
                                            <td>

                                                <?php if(Auth::user()->UserID != $active->UserID): ?>
                                                <button class="btn btn-danger archive_user" value=<?php echo e($active->UserID); ?> type="button"><i class="fas fa-archive"></i></button>
                                                <button type="button"
                                                        class="btn btn-primary" 
                                                        role="button" 
                                                        data-html="true" 
                                                        data-toggle="popover" 
                                                        data-trigger="focus" 
                                                        title="<?php echo e($active->FirstName); ?> <?php echo e($active->LastName); ?>" 
                                                        data-bs-content=
                                                        "<div><b>Contact #:</b><br><?php echo e($active->ContactNo); ?></div><br>
                                                        <div><b>Emergency Contact #:</b><br><?php echo e($active->EmContactNo); ?></div><br>
                                                        <div><b>E-Mail Address:</b><br><?php echo e($active->email); ?></div>">
                                                        <i class="fas fa-eye"></i>
                                                </button>
                                                <?php endif; ?>
                                               
                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <tr class="pageRow">
                                        <td colspan="6">
                                           <div class="d-flex justify-content-center pt-4"> <?php echo e($actives->links()); ?> </div>
                                        </td>
                                    </tr>

                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <div class="col">
                <div class="card text-white mb-3 gray-bg">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-7">
                                <h4 class="yellow">Archived Users</h4>
                            </div>
                            <small>These users will be deleted from the system one year after their account creation.</small>
                        </div>

                        &nbsp;

                        <div class="row">
                            <div class="container">
                                <table class="table table-hover">
                                    <thead>
                                    <tr class="table-yellow">
                                        <th scope="col">Name</th>
                                        <th scope="col">Type</th>
                                        <th scope="col">Action</th>

                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php $__currentLoopData = $restricteds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restricted): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="table-light">
                                            <th scope="row"><?php echo e($restricted->FirstName); ?> <?php echo e($restricted->LastName); ?></th>
                                            <td><?php echo e($restricted->UserType); ?></td>
                                            <td><button type="button"
                                                class="btn btn-primary" 
                                                role="button" 
                                                data-html="true" 
                                                data-toggle="popover" 
                                                data-trigger="focus" 
                                                title="<?php echo e($restricted->FirstName); ?> <?php echo e($restricted->LastName); ?>" 
                                                data-bs-content=
                                                "<div><b>Contact #:</b><br><?php echo e($restricted->ContactNo); ?></div><br>
                                                <div><b>Emergency Contact #:</b><br><?php echo e($restricted->EmContactNo); ?></div><br>
                                                <div><b>E-Mail Address:</b><br><?php echo e($restricted->email); ?></div>">
                                                <i class="fas fa-eye"></i>
                                                </button>
                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <tr class="pageRow">
                                        <td colspan="6">
                                           <div class="d-flex justify-content-center pt-4"> <?php echo e($restricteds->links()); ?> </div>
                                        </td>
                                    </tr>

                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>




    </div>

    <script src="../../js/users.js"></script>
    <script>
        $(document).ready(function(){
         $('[data-toggle="popover"]').popover({html: true});   
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.usersmodals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('masterlayout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\POS-MS\resources\views/admin/userManagement.blade.php ENDPATH**/ ?>