<!-- 

    <?php $__env->startSection('location'); ?>
        REPORT PREVIEW
    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('content'); ?>
        <div class="d-flex justify-content-end mb-4">
                <a class="btn btn-primary" href="<?php echo e(URL::to('/admin/PDF')); ?>">Export to PDF</a>
        </div>

        <h1>Date: </h1>
        <div class="container-fluid">
            <table class="table table-bordered mb-4">
                <thead>
                    <tr>
                        <th scope="col">Category</th>
                        <th scope="col">Amount Sold</th>
                        <th scope="col">Sales</th>
                        <th scope="col">% to total</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <tr>
                        <th scope="row">sample</th>
                        <th scope="row">sample</th>
                        <th scope="row">sample</th>
                        <th scope="row">sample</th>
                    </tr>
                </tbody>
            </table>

        </div>
        


<?php $__env->stopSection(); ?> -->

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Migui's Store Report</title>
      
    </head>
    <body>
        <h1>Migui's Store Report</h1>
        <h5>Yahallo</h5>
        <small><?php echo e($data); ?></small>
        <p><?php echo date("Y/m/d"); ?></p>
    </body>
</html>
<?php echo $__env->make('masterlayout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\POS-MS\resources\views/admin/reportPreview.blade.php ENDPATH**/ ?>