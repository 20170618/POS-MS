

<?php $__env->startSection('alert'); ?>
    <?php if($message = Session::get('deleteTransaction')): ?>
        <?php
        echo "<script>
                    Swal.fire(
                        'Deleted.',
                        'The sales record has been deleted.',
                        'danger'
                    )   </script> ";
        ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('location'); ?>
    DEBTORS
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container" style="margin-top: 10px">
        <div class="row">

            <div class="col">
                <div class="form-group">

                    <div class="form-group" style="width: 20rem;">
                        <div class="input-group mb-3">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" id="search" class="form-control" placeholder="Search">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="container">
                <table class="table table-hover">
                    <thead>
                        <tr style="text-align: center;">
                            <th scope="col">Debtor IDs</th>
                            <th scope="col">Name</th>
                            <th scope="col">Balance</th>
                            <th scope="col">Initial Payment</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>

                    <tbody id="transactionsBody">
                        <?php $__currentLoopData = $debtors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $debtor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="align-content: center; text-align: center;">

                                <th scope="row"><?php echo e($debtor->SalesID); ?></th>
                                <td><?php echo e($debtor->Debtor); ?></td>
                                <td><?php echo e(number_format((float)$debtor->Balance, 2, '.', '')); ?></td>
                                <td><?php echo e(number_format((float)$debtor->InitialPayment, 2, '.', '')); ?></td>
                                <td>
                                    <button class="btn btn-success debt_record" value="<?php echo e($debtor->SalesID); ?>"><i
                                            class="fas fa-check"></i></button>
                                    <a class="btn btn-primary" href=""><i class="fas fa-eye"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Start View Products of Debt Record -->
    <div id="DebtRecordModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header blue-bg yellow">
                    <h5 class="modal-title" id="DebtRecordModalHeader">Mark this debt record as paid?</h5>
                    <button type="button" class="btn-close dirty-white" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"></span>
                    </button>
                </div>
                <div class="modal-body">
                    <div id="DebtorsDebt">
                        <input type="hidden" id="delete_tran_id">
                        <div class="form-group">
                            <label for="Debtor Name" class="form-label mt-2">Debtor Name</label>
                            <div class="input-group">
                                <input type="text" class="form-control DebtorName" id="DebtorName" readonly>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="Amount Due" class="form-label mt-2">Last Amount Paid:</label>
                            <div class="input-group">
                                <input type="number" class="form-control LastAmountPaid" id="LastAmountPaid" readonly>
                            </div>
                        </div>
                        <div class="form-group mt-3">
                            <label for="Amount Due" class="form-label mt-2">Amount Due:</label>
                            <div class="input-group">
                                <input type="number" class="form-control deleteCategoryName" id="AmountDue" readonly>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="modal-footer" style="text-align: right">
                <button class="btn btn-warning clear_debt" type="button" data-bs-dismiss="modal" id="CurrentDebt">Yes</button>
                    <button class="btn btn-primary" type="button" data-bs-dismiss="modal">Cancel</button>
                </div>

            </div>
        </div>
    </div>
    <!-- End View Debt Record Modal -->

    <script>
        $(document).ready(function() {

            //Click Check Button
            $(document).on('click', '.debt_record', function() {

                $('#DebtRecordModal').modal('show');

                var debtorID = $(this).val();
                console.log(debtorID);


                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    type: "GET",
                    url: "debtors-record/" + debtorID,
                    success: function(response) {
                        if (response.status == 200) {

                            $.each(response.debtor, function(key, dRecord) {
                                $('#DebtorName').val(dRecord.Debtor);
                                $('#LastAmountPaid').val(dRecord.InitialPayment);
                                $('#AmountDue').val(dRecord.Balance);
                                $('#CurrentDebt').val(dRecord.SalesID);
                            });
                        } else {

                        }
                    }
                });

            });


            // Yes to clear the debt record
            $('.clear_debt').click(function (e) { 
                e.preventDefault();
                
                var debtid = $('#CurrentDebt').val();

                $.ajax({
                    type: "GET",
                    url: "debtors-clear/"+debtid,
                    success: function (response) {
                        
                        if(response.status==100){
                            Swal.fire(
                                'Success!',
                                response.message,
                                'success'
                                )
                            location.reload();
                        }

                    }
                });

            });

            // View the specific debt's transaction details
            $('.view_details').click(function (e) { 
                e.preventDefault();
                
            });


        });
        // End Delete
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('masterlayout.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\POS-MS\resources\views/admin/debtors.blade.php ENDPATH**/ ?>