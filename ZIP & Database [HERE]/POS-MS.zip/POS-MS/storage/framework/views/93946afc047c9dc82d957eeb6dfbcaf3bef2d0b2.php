<!-- start view food modal -->
<div id="viewFoodModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="my-modal-title" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header blue-bg yellow">
                <h5 class="modal-title">Groceries</h5>
                <button type="button" class="btn-close dirty-white" data-bs-dismiss="modal" aria-label="Close">
                <span aria-hidden="true"></span>
                </button>
            </div>
            <div class="modal-body">

                <div class="row">
                    <div class="container">
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th scope="col">Image</th>
                                <th scope="col">Name</th>
                                <th scope="col">Price</th>
                                <th scope="col">Actions</th>
                            </tr>
                            </thead>
                        
                        </table>
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>
<!-- end view food modal --><?php /**PATH C:\xampp\htdocs\POS-MS\resources\views/salesperson/salespersonmodals.blade.php ENDPATH**/ ?>